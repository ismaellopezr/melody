
import math
import matplotlib.pylab as plt
import numpy as np

wavearray=[]
class Seno:

        def __init__(self, sampling, bits):
            self.SamplingRate = sampling
            self.NumeroBit = bits


        def generar(self):

            duracion=int(44100*0.5)
            for i in range(0, duracion):

                    datos = math.sin((2*math.pi*(349.228231)*i)/44100)
                    wavearray.append(datos)

            duracion=int(44100*0.5)

            for i in range(0, duracion):

                    datos = math.sin((2*math.pi*(349.228231)*i)/44100)
                    wavearray.append(datos)

            duracion=int(44100*0.5)
            for i in range(0, duracion):

                    datos = math.sin((2*math.pi*(349.228231)*i)/44100)
                    wavearray.append(datos)

            duracion=int(44100*0.5)
            for i in range(0, duracion):

                    datos = math.sin((2*math.pi*(261.625565)*i)/44100)
                    wavearray.append(datos)

            duracion=int(44100*0.5)
            for i in range(0, duracion):

                    datos = math.sin((2*math.pi*(293.664768)*i)/44100)
                    wavearray.append(datos)

            duracion=int(44100*0.5)
            for i in range(0, duracion):

                    datos = math.sin((2*math.pi*(293.664768)*i)/44100)
                    wavearray.append(datos)

            duracion=int(44100*1)
            for i in range(0, duracion):

                    datos = math.sin((2*math.pi*(261.625565)*i)/44100)
                    wavearray.append(datos)

            FinalData = np.asarray(wavearray)

            return FinalData


        def leveladjust(self, datos, bits, level):
            peaklevel = max(abs(datos))
            print peaklevel
            valueLevel = (10**(level/20))*((2**16)/2.0)
            valueAdjust = valueLevel / float(peaklevel)
            datosAjustados = datos * valueAdjust
            print max(datosAjustados)
            return datosAjustados


        def graficar(self, array):
                plt.plot(array, color="green", linewidth=1.0, linestyle="-")
                plt.show()


